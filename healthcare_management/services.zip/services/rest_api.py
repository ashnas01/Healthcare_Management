# import healthcare_management;

# obj = healthcare_management.__file__;