import frappe
from frappe.model.naming import make_autoname
from datetime import datetime

@frappe.whitelist()
def generate_uid_series():
    year_suffix = datetime.now().strftime('%y')
    series = f"RDC-PT{year_suffix}-.#####."
    return make_autoname(series)