# Copyright (c) 2025, Sil and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestPharmacyBilling(FrappeTestCase):
	pass
