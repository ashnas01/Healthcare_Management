// Copyright (c) 2025, Sil and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Clinical Procedure Bill", {
// 	refresh(frm) {

// 	},
// });
